namespace Commander.Dtos
{
    public class CategoryReadDto
    {
        public int Id { get; set; }


        public string NameArbice { get; set; }



        public string NameEnglish { get; set; }



        public string NameFrance { get; set; }


        public string Image { get; set; }
    }
}
namespace Commander.Dtos
{
    public class CategoryUpdateDto
    {
         

        public string NameArbice { get; set; }



        public string NameEnglish { get; set; }



        public string NameFrance { get; set; }


        public string Image { get; set; }
    }
}
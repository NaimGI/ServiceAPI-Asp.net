namespace Commander.Models
{


    public class LoginSocail
    {



        public string email { get; set; }

        public string id { get; set; }

        public string Name { get; set; }


        public string Role { get; set; }
    }



}
namespace Commander.Models {


    public class General{

     

        public  string CounterAdds { get; set; }

        public string CounterCategories { get; set; }

        public string  CounterSub { get; set; }

    }



}
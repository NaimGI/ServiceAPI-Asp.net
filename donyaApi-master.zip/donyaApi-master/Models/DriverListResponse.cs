﻿using System;
namespace Commander.Models
{
    public class DriverListResponse
    {
        public Driver Driver { get; set; }
        public User User { get; set; }
        
    }
}

﻿using System;
namespace Commander.Models
{
    public class UserForValidate
    {
        public string UserName { get; set; }
        public string Email { get; set; }
    }
}

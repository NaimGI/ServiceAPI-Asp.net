using System.Collections.Generic;

namespace Commander.Models{



    class ResponseAdds{

public List<Adds> CurrentAdds { get; set; }

public List<Adds> UnacceptableAdds { get; set; }
public List<Adds> SpoonAdds { get; set; }
    }
}
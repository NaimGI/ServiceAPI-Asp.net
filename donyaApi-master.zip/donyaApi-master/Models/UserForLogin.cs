﻿using System;
namespace Commander.Models
{
    public class UserForLogin
    {
        public string userName { get; set; }
        public string code { get; set; }
    }
}

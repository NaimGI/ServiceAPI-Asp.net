using Newtonsoft.Json;

namespace Commander.Notification{


 public class FcmNotificationSetting
    {
        public string SenderId { get; set; }
        public string ServerKey { get; set; }
    }


}